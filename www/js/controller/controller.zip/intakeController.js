angular.module('starter.controllers')
.controller('IntakeFormsCtrl', function($scope, $ionicPlatform, $window, $ionicBackdrop,  htmlEscapeValue, $interval, $ionicSideMenuDelegate, replaceCardNumber, $ionicModal, $ionicPopup, $ionicHistory, $filter, $rootScope, $state, SurgeryStocksListService, LoginService, $timeout, CustomCalendar, CustomCalendarMonth) {
$("link[href*='css/styles.v3.less.dynamic.css']").attr("disabled", "disabled");
    $ionicPlatform.registerBackButtonAction(function() {
        if (($rootScope.currState.$current.name === "tab.userhome") ||
            ($rootScope.currState.$current.name === "tab.addCard") ||
            ($rootScope.currState.$current.name === "tab.submitPayment") ||
            ($rootScope.currState.$current.name === "tab.waitingRoom") ||
            ($rootScope.currState.$current.name === "tab.receipt") ||
            ($rootScope.currState.$current.name === "tab.videoConference") ||
            ($rootScope.currState.$current.name === "tab.connectionLost") ||
            ($rootScope.currState.$current.name === "tab.ReportScreen")
        ) {
            // H/W BACK button is disabled for these states (these views)
            // Do not go to the previous state (or view) for these states.
            // Do nothing here to disable H/W back button.
        } else if ($rootScope.currState.$current.name === "tab.login") {
            navigator.app.exitApp();
        } else if ($rootScope.currState.$current.name === "tab.loginSingle") {
            navigator.app.exitApp();
        } else if ($rootScope.currState.$current.name === "tab.chooseEnvironment") {
            navigator.app.exitApp();
        } else if ($rootScope.currState.$current.name === "tab.cardDetails") {
            var gSearchLength = $('.ion-google-place-container').length;
            if (($('.ion-google-place-container').eq(gSearchLength - 1).css('display')) === 'block') {
                $ionicBackdrop.release();
                $(".ion-google-place-container").css({
                    "display": "none"
                });
            } else {
                $(".ion-google-place-container").css({
                    "display": "none"
                });
                navigator.app.backHistory();
            }
        } else {
            navigator.app.backHistory();
        }
    }, 100);
    $rootScope.currState = $state;
    $rootScope.monthsList = CustomCalendar.getMonthsList();
    $rootScope.ccYearsList = CustomCalendar.getCCYearsList();
    $rootScope.limit = 4;
    $rootScope.Concernlimit = 1;
    $rootScope.checkedPrimary = 0;
    $scope.doGetSingleHosInfoForiTunesStage = function() {
        $rootScope.paymentMode = '';
        $rootScope.insuranceMode = '';
        $rootScope.onDemandMode = '';
        $rootScope.OrganizationLocation = '';
        $rootScope.PPIsBloodTypeRequired = '';
        $rootScope.PPIsHairColorRequired = '';
        $rootScope.PPIsEthnicityRequired = '';
        $rootScope.PPIsEyeColorRequired = '';
        var params = {
            hospitalId: $rootScope.hospitalId,
            success: function(data) {
                $rootScope.getDetails = data.data[0].enabledModules;
                $rootScope.ssopatienttoken = data.data[0].patientTokenApi;
                $rootScope.ssopatientregister = data.data[0].patientRegistrationApi;
                $rootScope.ssopatientforgetpwd = data.data[0].patientForgotPasswordApi;
                if ($rootScope.getDetails !== '') {
                    for (var i = 0; i < $rootScope.getDetails.length; i++) {
                        if ($rootScope.getDetails[i] === 'InsuranceVerification' || $rootScope.getDetails[i] === 'mInsVerification') {
                            $rootScope.insuranceMode = 'on';
                        }
                        if ($rootScope.getDetails[i] === 'ECommerce' || $rootScope.getDetails[i] === 'mECommerce') {
                            $rootScope.paymentMode = 'on';
                        }
                        if ($rootScope.getDetails[i] === 'OnDemand' || $rootScope.getDetails[i] === 'mOnDemand') {
                            $rootScope.onDemandMode = 'on';
                        }
                        if ($rootScope.getDetails[i] === 'OrganizationLocation' || $rootScope.getDetails[i] === 'mOrganizationLocation') {
                            $rootScope.OrganizationLocation = 'on';
                        }
                        if ($rootScope.getDetails[i] === 'PPIsBloodTypeRequired') {
                            $rootScope.PPIsBloodTypeRequired = 'on';
                        }
                        if ($rootScope.getDetails[i] === 'PPIsHairColorRequired') {
                            $rootScope.PPIsHairColorRequired = 'on';
                        }
                        if ($rootScope.getDetails[i] === 'PPIsEthnicityRequired') {
                            $rootScope.PPIsEthnicityRequired = 'on';
                        }
                        if ($rootScope.getDetails[i] === 'PPIsEyeColorRequired') {
                            $rootScope.PPIsEyeColorRequired = 'on';
                        }
                    }
                }
                $rootScope.brandColor = data.data[0].brandColor;
                $rootScope.logo = data.data[0].hospitalImage;
                $rootScope.Hospital = data.data[0].brandName;
                if (deploymentEnvLogout === 'Multiple') {
                    $rootScope.alertMsgName = 'Virtual Care';
                    $rootScope.reportHospitalUpperCase = $rootScope.Hospital.toUpperCase();
                } else {
                    $rootScope.alertMsgName = $rootScope.Hospital;
                    $rootScope.reportHospitalUpperCase = $rootScope.Hospital.toUpperCase();
                }
                $rootScope.HospitalTag = data.data[0].brandTitle;
                $rootScope.contactNumber = data.data[0].contactNumber;
                $rootScope.hospitalDomainName = data.data[0].hospitalDomainName;
                $rootScope.clientName = data.data[0].hospitalName;
                if (!angular.isUndefined(data.data[0].customerSso) && data.data[0].customerSso === "Mandatory") {
                    $rootScope.customerSso = "Mandatory";
                    ssoURL = data.data[0].patientLogin;
                } else {
                    $rootScope.customerSso = '';
                }
                if (!angular.isUndefined(data.data[0].patientRegistrationApi) && data.data[0].patientRegistrationApi !== "") {
                    $rootScope.isSSORegisterAvailable = data.data[0].patientRegistrationApi;
                } else {
                    $rootScope.isSSORegisterAvailable = '';
                }
                if (deploymentEnvLogout === "Multiple") {
                    $state.go('tab.chooseEnvironment');
                } else if (deploymentEnvLogout === "Single") {
                    $state.go('tab.loginSingle');
                } else {
                    $state.go('tab.login');
                }
            },
            error: function() {
                $rootScope.serverErrorMessageValidation();
            }
        };
        LoginService.getHospitalInfo(params);
    }

    $rootScope.ClearRootScope = function() {
      $window.localStorage.setItem('tokenExpireTime', '');
      if (deploymentEnvLogout === 'Single' && deploymentEnvForProduction === 'Production' && appStoreTestUserEmail === 'itunesmobiletester@gmail.com' && api_keys_env === 'Staging') {
            $rootScope.hospitalId = singleHospitalId;
            apiCommonURL = 'https://connectedcare.md';
            api_keys_env = 'Production';
            $rootScope.APICommonURL = 'https://connectedcare.md';
            $scope.doGetSingleHosInfoForiTunesStage();
      } else {
        if (deploymentEnvLogout === "Multiple") {
            $state.go('tab.chooseEnvironment');
        } else if (deploymentEnvLogout === "Single") {
            $state.go('tab.loginSingle');
        } else {
            $state.go('tab.login');
        }
      }
      $rootScope = $rootScope.$new(true);
      $scope = $scope.$new(true);
      for (var prop in $rootScope) {
          if (prop.substring(0,1) !== '$') {
              delete $rootScope[prop];
          }
      }
      $(".ion-google-place-container").css({
          "display": "none"
      });

      $ionicBackdrop.release();
    }
    $rootScope.checkPreLoadDataAndSelectionAndRebindSelectionList = function(selectedListItem, mainListItem) {
        angular.forEach(mainListItem, function(item) {
            item.checked = false;
        });
        if (!angular.isUndefined(selectedListItem)) {

            if (selectedListItem.length > 0) {
                angular.forEach(selectedListItem, function(value1) {
                    angular.forEach(mainListItem, function(value2) {
                        if (value1.description === value2.text) {
                            value2.checked = true;
                        }
                    });
                });
            }
        }
    };
var locationdet=$rootScope.locationdet;
$scope.locat=false;
    $scope.doGetExistingConsulatation = function() {
      var params = {
            consultationId: $rootScope.consultationId,
            accessToken: $rootScope.accessToken,
            success: function(data) {
                $scope.existingConsultation = data;
                $rootScope.consultionInformation = data.data[0].consultationInfo;
                $rootScope.inTakeForm = data.data[0].intakeForm;
                $rootScope.inTakeFormCurrentMedication = $rootScope.inTakeForm.medications;
                if (!angular.isUndefined($rootScope.inTakeFormCurrentMedication)) {
                    $rootScope.MedicationCountValid = $rootScope.inTakeFormCurrentMedication.length;
                    if (typeof $rootScope.MedicationCountValid !== 'undefined' && $rootScope.MedicationCountValid !== '') {
                        $scope.checkPreLoadDataAndSelectionAndRebindSelectionList($rootScope.inTakeFormCurrentMedication, $rootScope.CurrentMedicationList);
                        $rootScope.CurrentMedicationItem = $filter('filter')($scope.CurrentMedicationList, {
                            checked: true
                        });
                        $rootScope.patinentCurrentMedication = $rootScope.CurrentMedicationItem;
                        if ($rootScope.patinentCurrentMedication) {
                            $rootScope.MedicationCount = $scope.patinentCurrentMedication.length;
                            $rootScope.MedicationCountValid = $rootScope.MedicationCount;
                        }

                    }
                }
                $rootScope.inTakeFormChronicConditions = $rootScope.inTakeForm.medicalConditions;
                if (!angular.isUndefined($rootScope.inTakeFormChronicConditions)) {
                    $rootScope.ChronicValid = $rootScope.inTakeFormChronicConditions.length;
                    $rootScope.ChronicCount = $rootScope.inTakeFormChronicConditions.length;
                    if (typeof $rootScope.ChronicValid !== 'undefined' && $rootScope.ChronicValid !== '') {
                        $scope.checkPreLoadDataAndSelectionAndRebindSelectionList($rootScope.inTakeFormChronicConditions, $rootScope.chronicConditionList);

                        $rootScope.PatientChronicConditionItem = $filter('filter')($rootScope.chronicConditionList, {
                            checked: true
                        });
                        $rootScope.PatientChronicCondition = $rootScope.PatientChronicConditionItem;
                        $rootScope.PatientChronicConditionsSelected = $rootScope.PatientChronicConditionItem;
                        if ($rootScope.PatientChronicCondition) {
                            $rootScope.ChronicCountValidCount = $rootScope.PatientChronicCondition.length;
                            $rootScope.ChronicCount = $rootScope.inTakeFormChronicConditions.length;
                        }
                    }
                }
                $rootScope.inTakeFormPriorSurgeories = $rootScope.inTakeForm.surgeries;
                if (!angular.isUndefined($rootScope.inTakeFormPriorSurgeories)) {
                    $rootScope.PriorSurgeryValid = $rootScope.inTakeFormPriorSurgeories.length;
                    if (typeof $rootScope.PriorSurgeryValid !== 'undefined' && $rootScope.PriorSurgeryValid !== '') {
                        SurgeryStocksListService.ClearSurgery();
                        angular.forEach($rootScope.inTakeFormPriorSurgeories, function(Priorvalue) {
                            var surgeryMonthName = Priorvalue.month;
                            var PriorSurgeryDate = new Date(Priorvalue.year, surgeryMonthName - 1, 01);
                            var dateString = PriorSurgeryDate;
                            var surgeryName = Priorvalue.description;
                            var stockSurgery = SurgeryStocksListService.addSurgery(surgeryName, dateString);
                            $rootScope.patientSurgeriess = SurgeryStocksListService.SurgeriesList;
                            $rootScope.IsToPriorCount = $rootScope.patientSurgeriess.length;
                        });
                        $rootScope.PriorSurgeryValidCount = $rootScope.IsToPriorCount;
                    }
                }
                $rootScope.inTakeFormMedicationAllergies = $rootScope.inTakeForm.medicationAllergies;
                if (!angular.isUndefined($rootScope.inTakeFormMedicationAllergies)) {
                    $rootScope.AllegiesCountValid = $rootScope.inTakeFormMedicationAllergies.length;
                    if (typeof $rootScope.AllegiesCountValid !== 'undefined' && $rootScope.AllegiesCountValid !== '') {
                        $scope.checkPreLoadDataAndSelectionAndRebindSelectionList($rootScope.inTakeFormMedicationAllergies, $rootScope.MedicationAllegiesList);
                        $rootScope.MedicationAllegiesItem = $filter('filter')($rootScope.MedicationAllegiesList, {
                            checked: true
                        });
                        $rootScope.patinentMedicationAllergies = $rootScope.MedicationAllegiesItem;
                        if ($rootScope.patinentMedicationAllergies) {
                            $rootScope.AllegiesCount = $scope.patinentMedicationAllergies.length;
                            $rootScope.AllegiesCountValid = $rootScope.AllegiesCount;
                        }
                    }
                }
                $state.go('tab.ChronicCondition');
            },
            error: function(data) {
                $scope.existingConsultation = 'Error getting existing consultation';
            }
        };
        LoginService.getExistingConsulatation(params);
    }

    $scope.goBackFromConcern = function() {
    $state.go(locationdet);
    }
    $scope.model = null;
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    $rootScope.PreviousDate = yyyy + '-' + mm + '-' + dd; //Previous Month 2015-06-23
    $rootScope.PopupValidation = function($a) {
        function refresh_close() {
            $('.close').click(function() {
                $(this).parent().fadeOut(200);
                $rootScope.PrimaryPopup = $rootScope.PrimaryPopup - 1;
            });
        }
        refresh_close();
        $rootScope.PrimaryPopup = $rootScope.PrimaryPopup + 1;
        var top = '<div class="notifications-top-center notificationError"><div class="ErrorContent"> <i class="ion-alert-circled" style="font-size: 22px;"></i> ' + $a + '! </div><div id="notifications-top-center-close" class="close NoticationClose"><span class="ion-ios-close-outline" ></span></div></div>';
        $("#notifications-top-center").remove();
        $(".PopupError_Message").append(top);
        refresh_close();

    }
    // Get list of primary concerns lists
    $scope.primaryConcernList = $rootScope.hospitalCodesList;
    $scope.loadPrimaryConcerns = function() {
    $scope.data.searchProvider='';
    $scope.clearSelectionAndRebindSelectionList($rootScope.PatientPrimaryConcernItem, $scope.primaryConcernList);
      if ($rootScope.getSecondaryConcernAPIList !== "") {
            if (typeof $scope.PatientPrimaryConcernItem !== 'undefined') {
                if ($rootScope.IsValue !== '') {
                    $rootScope.getCheckedPrimaryConcern = $filter('filter')($scope.primaryConcernList, {
                        text: $rootScope.PrimaryConcernText
                    });
                    $rootScope.getCheckedPrimaryConcern[0].checked = true;
                }
                if ($rootScope.IsValue === '') {
                    $rootScope.getCheckedPrimaryConcern = $filter('filter')($scope.primaryConcernList, {
                        text: $rootScope.PrimaryConcernText
                    });
                    $rootScope.getCheckedPrimaryConcern[0].checked = false;
                }
            }
            if (typeof $scope.PatientSecondaryConcernItem !== 'undefined') {
                $scope.getCheckedSecondaryConcern = $filter('filter')($scope.secondaryConcernList, {
                    text: $rootScope.SecondaryConcernText
                });
                $scope.getCheckedSecondaryConcern[0].checked = false;
            }
        }
        if (typeof $rootScope.PrimaryCount === "") {
              $rootScope.checkedPrimary = "";
        } else {
            $rootScope.checkedPrimary = $rootScope.PrimaryCount;
        }
        $ionicModal.fromTemplateUrl('templates/tab-ConcernsList.html', {
            scope: $scope,
            animation: 'slide-in-up',
            focusFirstInput: false,
            backdropClickToClose: false
        }).then(function(modal) {
            $scope.modal = modal;
            $scope.modal.show();
        });
    };
    $scope.closePrimaryConcerns = function() {
        $rootScope.PatientPrimaryConcernItem = $filter('filter')($scope.primaryConcernList, {
            checked: true
        });
        if ($scope.PatientPrimaryConcernItem !== '') {
            $rootScope.PrimaryConcernText = $scope.PatientPrimaryConcernItem[0].text;
            $rootScope.codeId = $scope.PatientPrimaryConcernItem[0].codeId;
            if (typeof $rootScope.PatientSecondaryConcern[0] !== 'undefined') {
                if ($scope.PatientPrimaryConcernItem[0].text === $rootScope.PatientSecondaryConcern[0].text) {
                    $scope.ErrorMessage = "Primary and Secondary Concerns must be different";
                    $rootScope.ValidationFunction1($scope.ErrorMessage);
                } else {
                    $rootScope.PatientPrimaryConcern = $scope.PatientPrimaryConcernItem;
                    $rootScope.IsValue = $scope.PatientPrimaryConcernItem.length;
                      $rootScope.PrimaryCount = $scope.PatientPrimaryConcernItem.length;
                    $scope.modal.hide();
                }
            } else {
                $rootScope.PatientPrimaryConcern = $scope.PatientPrimaryConcernItem;
                $rootScope.IsValue = $scope.PatientPrimaryConcernItem.length;
                  $rootScope.PrimaryCount = $scope.PatientPrimaryConcernItem.length;
                $scope.modal.hide();
            }
        }
    };
    // Onchange of primary concerns
    $scope.OnSelectPatientPrimaryConcern = function(position, primaryConcernList, items) {
        angular.forEach(primaryConcernList, function(item) {
            if (item.text === items.text)
                item.checked = true;
            else item.checked = false;
        });
        if (items.text === "Other (provide details below)")
            $scope.openOtherPrimaryConcernView();
        else $scope.closePrimaryConcerns();

    }
    $rootScope.PrimaryPopup = 0;
    // Open text view for other primary concern
    $scope.openOtherPrimaryConcernView = function() {
        $scope.data = {}
        $ionicPopup.show({
            template: '<div class="PopupError_Message ErrorMessageDiv" ></div><textarea name="comment" id="comment-textarea" ng-model="data.PrimaryConcernOther" class="textAreaPop">',
            title: 'Enter Primary Concern',
            subTitle: '',
            scope: $scope,
            buttons: [{
                text: 'Cancel',
                onTap: function(e) {
                    angular.forEach($scope.primaryConcernList, function(item) {
                        item.checked = false;
                    });
                }
            }, {
                text: '<b>Done</b>',
                type: 'button-positive',
                onTap: function(e) {
                    if (!$scope.data.PrimaryConcernOther) {
                        if ($rootScope.PrimaryPopup === 0) {
                            $scope.ErrorMessages = "Please enter a reason for today's visit";
                            $rootScope.PopupValidation($scope.ErrorMessages);
                        }
                        e.preventDefault();
                    } else {
                        angular.forEach($scope.primaryConcernList, function(item) {
                            item.checked = false;
                        });
                        var newPrimaryConcernItem = {
                            text: $scope.data.PrimaryConcernOther,
                            checked: true
                        };
                        $scope.primaryConcernList.splice(1, 0, newPrimaryConcernItem);
                        $scope.closePrimaryConcerns();
                        return $scope.data.PrimaryConcernOther;
                    }
                }
            }]
        });
    };

    $scope.removePrimaryConcern = function(index, item) {
            $rootScope.PatientPrimaryConcern.splice(index, 1);
            var indexPos = $scope.primaryConcernList.indexOf(item);
            $scope.primaryConcernList[indexPos].checked = false;
            $rootScope.IsValue = $rootScope.PatientPrimaryConcern.length;
            $rootScope.IsValue = $scope.primaryConcernList;
            $rootScope.IsValue = "";
        }
    $rootScope.PrimaryNext = 0;
    $rootScope.ConcernsValidation = function($a) {
        function refresh_close() {
            $('.close').click(function() {
                $(this).parent().fadeOut(200);
                $rootScope.PrimaryNext = $rootScope.PrimaryNext - 1;
            });
        }
        refresh_close();
        $rootScope.PrimaryNext = $rootScope.PrimaryNext + 1;
        var top = '<div class="notifications-top-center notificationError"><div class="ErrorContent"> <i class="ion-alert-circled" style="font-size: 23px;"></i> ' + $a + '! </div><div id="notifications-top-center-close" class="close NoticationClose"><span class="ion-ios-close-outline" ></span></div></div>';
        $("#notifications-top-center").remove();
        $(".Error_Message").append(top);
        refresh_close();
    }
    $scope.PatientConcernsDirectory = function(ChronicValid) {
        $rootScope.ChronicValid = ChronicValid; // pre populated valid value
        $rootScope.IsValue = $rootScope.PatientPrimaryConcern.length;
        if ($rootScope.IsValue === 0 || $rootScope.IsValue === undefined) {
            if ($rootScope.PrimaryNext === 0) {
                $scope.ErrorMessage = "Primary Concern Can't be Empty";
                $rootScope.ConcernsValidation($scope.ErrorMessage);
            }
        } else {
            $rootScope.birHistory = {};
            $scope.doPostOnDemandConsultation();
        }
    }
    $scope.doGetConcentToTreat = function() {
        var params = {
            documentType: 2,
            hospitalId: $rootScope.hospitalId,
            success: function(data) {
                $rootScope.concentToTreatContent = htmlEscapeValue.getHtmlEscapeValue(data.data[0].documentText);
                $state.go('tab.ConsentTreat');
            },
            error: function(data) {
              if(data =='null' ){
             $scope.ErrorMessage = "Internet connection not available, Try again later!";
             $rootScope.Validation($scope.ErrorMessage);
           }else{
               $rootScope.serverErrorMessageValidation();
           }
            }
        };
        LoginService.getConcentToTreat(params);
    }

    $scope.goToConsentToTreat = function() {
        if($rootScope.userAgeForIntake === 8) {
          if (typeof $("input[name='birthBorn']:checked").val() === 'undefined' || $("input[name='birthBorn']:checked").val() === ' ') {
              $scope.ErrorMessage = "Please choose if the patient was born at full term or not?";
              $rootScope.ValidationFunction1($scope.ErrorMessage);
          } else if (typeof $("input[name='birthVagin']:checked").val() === 'undefined' || $("input[name='birthVagin']:checked").val() === ' ') {
              $scope.ErrorMessage = "Please choose if the patient was born vaginally or not?";
              $rootScope.ValidationFunction1($scope.ErrorMessage);
          } else if (typeof $("input[name='birthDischargedwithMother']:checked").val() === 'undefined' ||$("input[name='birthDischargedwithMother']:checked").val() === ' ') {
              $scope.ErrorMessage = "Please choose if the patient was discharged with the Mother or not? ";
              $rootScope.ValidationFunction1($scope.ErrorMessage);
          } else if (typeof $("input[name='birthVaccination']:checked").val() === 'undefined' || $("input[name='birthVaccination']:checked").val() === ' ') {
              $scope.ErrorMessage = "Please choose if the patients vaccinations are up-to-date or not?";
              $rootScope.ValidationFunction1($scope.ErrorMessage);
          }else {
            $scope.ConsultationSaveData.infantData = {
              "patientAgeUnderOneYear": "Y",
              "fullTerm": $("input[name='birthBorn']:checked").val(),
              "vaginalBirth": $("input[name='birthVagin']:checked").val(),
              "dischargedWithMother": $("input[name='birthDischargedwithMother']:checked").val(),
              "vaccinationsCurrent": $("input[name='birthVaccination']:checked").val()
            }
            $rootScope.appointmentsPage = false;
            $scope.doGetConcentToTreat();
          }
        } else {
          $scope.ConsultationSaveData.infantData = {
            "patientAgeUnderOneYear": "",
            "fullTerm": "",
            "vaginalBirth": "",
            "dischargedWithMother": "",
            "vaccinationsCurrent": ""
          }
          $rootScope.appointmentsPage = false;
          $scope.doGetConcentToTreat();
        }
    };
    $scope.goToHealthHistory = function() {
      if($rootScope.userAgeForIntake === 8) {
            $state.go('tab.intakeBornHistory');
      }else {
            $scope.goToConsentToTreat();
      }
    };
    $scope.data = {};
    $scope.$watch('data.searchProvider', function(searchKey) {
        $rootScope.providerSearchKey = searchKey;
        if (typeof $rootScope.providerSearchKey === 'undefined') {
            $scope.data.searchProvider = $rootScope.backProviderSearchKey;
        }
        if ($rootScope.providerSearchKey !== '' && typeof $rootScope.providerSearchKey !== 'undefined') {
            $rootScope.iconDisplay = 'none';
        } else {
            $rootScope.iconDisplay = 'Block';
        }
    });
    $scope.secondaryConcernList = $rootScope.scondaryConcernsCodesList;
    $scope.loadSecondaryConcerns = function() {
        $scope.data.searchProvider='';
        if ($rootScope.getSecondaryConcernAPIList !== "") {
            if ($scope.PatientPrimaryConcernItem !== '') {
                $scope.getCheckedPrimaryConcern = $filter('filter')($scope.primaryConcernList, {
                    text: $rootScope.PrimaryConcernText
                });
                $scope.getCheckedPrimaryConcern[0].checked = false;
            }
            if (typeof $scope.PatientSecondaryConcernItem !== 'undefined') {
                if ($rootScope.secondaryConcernLength !== '') {
                    $scope.getCheckedSecondaryConcern = $filter('filter')($scope.secondaryConcernList, {
                        text: $rootScope.SecondaryConcernText
                    });
                    $scope.getCheckedSecondaryConcern[0].checked = true;
                }

                if ($rootScope.secondaryConcernLength === '') {
                    $scope.getCheckedSecondaryConcern = $filter('filter')($scope.secondaryConcernList, {
                        text: $rootScope.SecondaryConcernText
                    });
                    $scope.getCheckedSecondaryConcern[0].checked = false;
                }
            }
            if (typeof $scope.PatientSecondaryConcernItem === 'undefined') {
                if ($rootScope.secondaryConcernLength !== '') {
                    $scope.getCheckedSecondaryConcern = $filter('filter')($scope.secondaryConcernList, {
                        text: $rootScope.SecondaryConcernText
                    });
                    $scope.getCheckedSecondaryConcern[0].checked = false;
                }
            }
        }
        $ionicModal.fromTemplateUrl('templates/tab-SecondaryConcernsList.html', {
            scope: $scope,
            animation: 'slide-in-up',
            focusFirstInput: false,
            backdropClickToClose: false
        }).then(function(modal) {
            $scope.modal = modal;
            $scope.modal.show();
        });
    };
    $scope.closeSecondaryConcerns = function() {
        $scope.PatientSecondaryConcernItem = $filter('filter')($scope.secondaryConcernList, {
            checked: true
        });
        if ($scope.PatientSecondaryConcernItem !== '') {
            $rootScope.SecondaryConcernText = $scope.PatientSecondaryConcernItem[0].text;
            $rootScope.SecondarycodeId = $scope.PatientSecondaryConcernItem[0].codeId;
            if (typeof $rootScope.PatientPrimaryConcern[0] !== 'undefined') {
                if ($scope.PatientSecondaryConcernItem[0].text === $rootScope.PatientPrimaryConcern[0].text) {
                    $scope.ErrorMessage = "Primary and Secondary Concerns must be different";
                    $rootScope.ValidationFunction1($scope.ErrorMessage);
                } else {
                    $rootScope.PatientSecondaryConcern = $scope.PatientSecondaryConcernItem;
                    $scope.modal.hide();
                }
            } else {
                $rootScope.PatientSecondaryConcern = $scope.PatientSecondaryConcernItem;
                $scope.modal.hide();
            }
        }
    };
    // Onchange of Secondary concerns
    $scope.OnSelectPatientSecondaryConcern = function(position, secondaryConcernList, items) {
        angular.forEach(secondaryConcernList, function(item) {
            if (item.text == items.text)
                item.checked = true;
            else item.checked = false;
        });
        if (items.text === "Other (provide details below)") {
            $scope.openOtherSecondaryConcernView();
            item.checked = false;
        } else {
            $scope.closeSecondaryConcerns();
        }
    }
    // Open text view for other Secondary concern
    $scope.openOtherSecondaryConcernView = function() {
        $scope.data = {}
        $ionicPopup.show({
            template: '<textarea name="comment" id="comment-textarea" ng-model="data.SecondaryConcernOther" class="textAreaPop">',
            title: 'Enter Secondary Concern',
            subTitle: '',
            scope: $scope,
            buttons: [{
                text: 'Cancel',
                onTap: function(e) {
                    angular.forEach($scope.secondaryConcernList, function(item) {
                        item.checked = false;
                    });
                }
            }, {
                text: '<b>Done</b>',
                type: 'button-positive',
                onTap: function(e) {
                    if (!$scope.data.SecondaryConcernOther) {
                        e.preventDefault();
                    } else {
                        angular.forEach($scope.secondaryConcernList, function(item) {
                            item.checked = false;
                        });
                        var newSecodaryConcernItem = {
                            text: $scope.data.SecondaryConcernOther,
                            checked: true
                        };
                        $scope.secondaryConcernList.splice(1, 0, newSecodaryConcernItem);
                        $scope.closeSecondaryConcerns();
                        return $scope.data.SecondaryConcernOther;
                    }
                }
            }]
        });
    };
    $scope.removeSecondaryConcern = function(index, item) {
        $rootScope.PatientSecondaryConcern.splice(index, 1);
        var indexPos = $scope.secondaryConcernList.indexOf(item);
        $scope.secondaryConcernList[indexPos].checked = false;
        $rootScope.secondaryConcernLength = $rootScope.PatientSecondaryConcern.length;
        $rootScope.SecondaryConcernText = '';
    }
    /*Secondary concern End here*/
    $scope.OnDemandConsultationSaveData = {
        "concerns": [],
        "patientId": $rootScope.patientId
    }
    if ($rootScope.mobilePhone !== '') {
        $scope.OnDemandConsultationSaveData["phone"] = $rootScope.mobilePhone;
    } else if ($rootScope.mobilePhone === '') {
        $scope.OnDemandConsultationSaveData["phone"] = $rootScope.homePhone;
    }
  $scope.doPostOnDemandConsultation = function() {
        if (typeof $rootScope.PrimaryConcernText !== 'undefined') {
            $scope.primaryFilter = $filter('filter')($scope.OnDemandConsultationSaveData.concerns, {
                description: $rootScope.PrimaryConcernText
            });
            if ($scope.primaryFilter.length === 0) {
                $scope.OnDemandConsultationSaveData.concerns.push({
                    isPrimary: true,
                    description: $rootScope.PrimaryConcernText
                });
            }
        }
        if (typeof $rootScope.SecondaryConcernText !== 'undefined' && $rootScope.SecondaryConcernText !== "") {
            $scope.sceondFilter = $filter('filter')($scope.OnDemandConsultationSaveData.concerns, {
                description: $rootScope.SecondaryConcernText
            });
            if ($scope.sceondFilter.length === 0) {
                $scope.OnDemandConsultationSaveData.concerns.push({
                    isPrimary: false,
                    description: $rootScope.SecondaryConcernText
                });
            }
        }
        var params = {
            accessToken: $rootScope.accessToken,
            OnDemandConsultationData: $scope.OnDemandConsultationSaveData,
            patientId: $rootScope.patientId,
            success: function(data) {
                $rootScope.OnDemandConsultationSaveResult = data.data[0];
                $rootScope.consultationAmount = $rootScope.OnDemandConsultationSaveResult.consultationAmount;
                $rootScope.copayAmount = $rootScope.OnDemandConsultationSaveResult.consultationAmount;
                $rootScope.consultationId = $rootScope.OnDemandConsultationSaveResult.consultationId;
                $scope.doGetExistingConsulatation();
            },
            error: function(data,status) {
              if(status===0 ){
                   $scope.ErrorMessage = "Internet connection not available, Try again later!";
                   $rootScope.Validation($scope.ErrorMessage);

              }else{
                $rootScope.serverErrorMessageValidation();
              }
            }
        };
        LoginService.postOnDemandConsultation(params);
    };
    $scope.clearSelectionAndRebindSelectionList = function(selectedListItem, mainListItem) {
        angular.forEach(mainListItem, function(item, key2) {
            item.checked = false;
        });
        if (!angular.isUndefined(selectedListItem)) {
            if (selectedListItem.length > 0) {
                angular.forEach(selectedListItem, function(value1, key1) {
                    angular.forEach(mainListItem, function(value2, key2) {
                        if (value1.text === value2.text) {
                            value2.checked = true;
                        }
                    });
                });
            }
        }
    };
    $scope.BackToChronicCondition = function(ChronicValid) {
        $rootScope.ChronicValid = ChronicValid;
        $state.go('tab.ChronicCondition');
    }
    // Open Chronic Condition popup
    $scope.loadChronicCondition = function() {
        $scope.data.searchProvider='';
        $scope.clearSelectionAndRebindSelectionList($rootScope.PatientChronicConditionsSelected, $rootScope.chronicConditionList);
        if (typeof $rootScope.ChronicCount === 'undefined') {
            $rootScope.checkedChronic = 0;
        } else {
            $rootScope.checkedChronic = $rootScope.ChronicCount;
        }

        $ionicModal.fromTemplateUrl('templates/tab-ChronicConditionList.html', {
            scope: $scope,
            animation: 'slide-in-up',
            focusFirstInput: false,
            backdropClickToClose: false
        }).then(function(modal) {
            $scope.modal = modal;
            $scope.modal.show();
        });
    };

    $scope.closeChronicCondition = function() {
        $rootScope.PatientChronicConditionItem = $filter('filter')($scope.chronicConditionList, {
            checked: true
        });
        $rootScope.PatientChronicConditionsSelected = $filter('filter')($scope.chronicConditionList, {
            checked: true
        });
        if ($scope.PatientChronicConditionItem !== '') {
            $rootScope.PatientChronicCondition = $rootScope.PatientChronicConditionItem;
            $rootScope.ChronicCount = $rootScope.PatientChronicCondition.length;
            $scope.modal.hide();
        }
    };

    // Onchange of Chronic Condition
    $scope.OnSelectChronicCondition = function(item) {
        if (item.checked === true) {
            $rootScope.checkedChronic++;
        } else {
            $rootScope.checkedChronic--;
        }
      if ($rootScope.checkedChronic === 4) {
            $scope.closeChronicCondition();
        }
    }
    // Open text view for other Chronic Condition
    $scope.openOtherChronicConditionView = function() {
        $scope.data = {}
        $ionicPopup.show({
            template: '<textarea name="comment" id="comment-textarea" ng-model="data.ChronicCondtionOther" class="textAreaPop">',
            title: 'Enter Concerns',
            subTitle: '',
            scope: $scope,
            buttons: [{
                text: 'Cancel',
                onTap: function(e) {
                    angular.forEach($scope.chronicConditionList, function(item) {
                        if (item.checked) {
                            if (item.text === "Other")
                             item.checked = false;
                        }
                    });
                    $rootScope.checkedChronic--;
                }
            }, {
                text: '<b>Done</b>',
                type: 'button-positive',
                onTap: function(e) {
                    if (!$scope.data.ChronicCondtionOther) {
                        e.preventDefault();
                    } else {
                        angular.forEach($scope.chronicConditionList, function(item) {
                            if (item.checked) {
                                if (item.text == "Other") {
                                    item.checked = false;
                                }
                            }
                        });
                        var newchronicConditionItem = {
                            text: $scope.data.ChronicCondtionOther,
                            checked: true
                        };
                        $rootScope.chronicConditionList.splice(1, 0, newchronicConditionItem);
                        return $scope.data.ChronicCondtionOther;
                    }
                }
            }]
        });
    };
    $scope.removeChronicCondition = function(index, item) {
        $rootScope.PatientChronicCondition.splice(index, 1);
        var indexPos = $rootScope.chronicConditionList.indexOf(item);
        $rootScope.chronicConditionList[indexPos].checked = false;
        $rootScope.ChronicCount = $rootScope.PatientChronicCondition.length;
        $rootScope.checkedChronic--;
        $rootScope.PatientChronicConditionsSelected = $filter('filter')($scope.chronicConditionList, {
            checked: true
        });
    }
    $scope.GoToMedicationAllegies = function(AllegiesCountValid) {
            $state.go('tab.MedicationAllegies');
        }
        // Open Medication Allegies List popup
    $scope.loadMedicationAllegies = function() {
          $scope.data.searchProvider='';
        $scope.clearSelectionAndRebindSelectionList($rootScope.MedicationAllegiesItem, $rootScope.MedicationAllegiesList);
        if (typeof $rootScope.AllegiesCount === 'undefined') {
            $rootScope.checkedAllergies = 0;
        } else {
            $rootScope.checkedAllergies = $rootScope.AllegiesCount;
        }
        $ionicModal.fromTemplateUrl('templates/tab-MedicationAllegiesList.html', {
            scope: $scope,
            animation: 'slide-in-up',
            focusFirstInput: false,
            backdropClickToClose: false
        }).then(function(modal) {
            $scope.modal = modal;
            $scope.modal.show();
        });
    };
    $scope.closeMedicationAllegies = function() {
        $rootScope.MedicationAllegiesItem = $filter('filter')($scope.MedicationAllegiesList, {
            checked: true
        });
        if ($rootScope.MedicationAllegiesItem !== '') {
            $rootScope.patinentMedicationAllergies = $rootScope.MedicationAllegiesItem;
            $rootScope.AllegiesCount = $scope.patinentMedicationAllergies.length;
            $scope.modal.hide();
        }
    };
    // Onchnge of Medication Alligies
    $scope.OnSelectMedicationAllegies = function(item) {
        if (item.checked === true) {
            $rootScope.checkedAllergies++;
        } else {
            $rootScope.checkedAllergies--;
        }
        if ($rootScope.checkedAllergies === 4) {
            $scope.closeMedicationAllegies();
        }
    }
    // Open text view for other Medication Allergies
    $scope.openOtherMedicationAllgiesView = function() {
        $scope.data = {}
        $ionicPopup.show({
            template: '<textarea name="comment" id="comment-textarea" ng-model="data.MedicationAllergiesOther" class="textAreaPop">',
            title: 'Enter Concerns',
            subTitle: '',
            scope: $scope,
            buttons: [{
                text: 'Cancel',
                onTap: function(e) {
                    angular.forEach($scope.MedicationAllegiesList, function(item) {
                        if (item.checked) {
                            if (item.text === "Other")
                            item.checked = false;
                        }
                    });
                    $rootScope.checkedAllergies--;
                }
            }, {
                text: '<b>Done</b>',
                type: 'button-positive',
                onTap: function(e) {
                    if (!$scope.data.MedicationAllergiesOther) {
                        e.preventDefault();
                    } else {
                        angular.forEach($scope.MedicationAllegiesList, function(item) {
                            if (item.checked) {
                                if (item.text === "Other") {
                                    item.checked = false;
                                }
                            }
                        });
                        var newMedicationAllegiesItem = {
                            text: $scope.data.MedicationAllergiesOther,
                            checked: true
                        };
                        $rootScope.MedicationAllegiesList.splice(1, 0, newMedicationAllegiesItem);
                        $scope.closeMedicationAllegies();
                        return $scope.data.MedicationAllergiesOther;
                    }
                }
            }]
        });
    };
    $scope.removeMedicationAllegies = function(index, item) {
        $scope.patinentMedicationAllergies.splice(index, 1);
        var indexPos = $rootScope.MedicationAllegiesList.indexOf(item);
        $rootScope.MedicationAllegiesList[indexPos].checked = false;
        $rootScope.AllegiesCount = $scope.patinentMedicationAllergies.length;
        $rootScope.checkedAllergies--;
        $rootScope.MedicationAllegiesItem = $filter('filter')($scope.MedicationAllegiesList, {
            checked: true
        });
    }
  $scope.GoToCurrentMedication = function(MedicationCountValid) {
        $state.go('tab.CurrentMedication');
    }
    // Open Current Medication popup
    $scope.loadCurrentMedication = function() {
      $scope.data.searchProvider='';
  $scope.clearSelectionAndRebindSelectionList($rootScope.CurrentMedicationItem, $rootScope.CurrentMedicationList);
        if (typeof $rootScope.MedicationCount === 'undefined') {
            $rootScope.checkedMedication = 0;
        } else {
            $rootScope.checkedMedication = $rootScope.MedicationCount;
        }
        $ionicModal.fromTemplateUrl('templates/tab-CurrentMedicationList.html', {
            scope: $scope,
            animation: 'slide-in-up',
            focusFirstInput: false,
            backdropClickToClose: false
        }).then(function(modal) {
            $scope.modal = modal;
            $scope.modal.show();
        });
    };
    $scope.closeCurrentMedication = function() {
        $rootScope.CurrentMedicationItem = $filter('filter')($scope.CurrentMedicationList, {
            checked: true
        });
        if ($rootScope.CurrentMedicationItem !== '') {
            $rootScope.patinentCurrentMedication = $rootScope.CurrentMedicationItem;
            $rootScope.MedicationCount = $scope.patinentCurrentMedication.length;
            $scope.modal.hide();
        }
    };
    // Onchange of Current Medication
    $scope.OnSelectCurrentMedication = function(item) {
        if (item.checked === true) {
            $rootScope.checkedMedication++;
        } else {
            $rootScope.checkedMedication--;
        }
        if (item.text === "Other - (List below)") {
            $scope.openOtherCurrentMedicationView(item);
        } else {
            if ($rootScope.checkedMedication === 4) {
                $scope.closeCurrentMedication();
            }
        }
    }
    // Open text view for other Current Medication
    $scope.openOtherCurrentMedicationView = function() {
        $scope.data = {}
        $ionicPopup.show({
            template: '<textarea name="comment" id="comment-textarea" ng-model="data.CurrentMedicationOther" class="textAreaPop">',
            title: 'Enter Medication',
            subTitle: '',
            scope: $scope,
            buttons: [{
                text: 'Cancel',
                onTap: function(e) {
                    angular.forEach($scope.CurrentMedicationList, function(item) {
                        if (item.checked) {
                            if (item.text === "Other - (List below)") item.checked = false;
                        }
                    });
                    $rootScope.checkedMedication--;
                }
            }, {
                text: '<b>Done</b>',
                type: 'button-positive',
                onTap: function(e) {
                    if (!$scope.data.CurrentMedicationOther) {
                        e.preventDefault();
                    } else {
                        angular.forEach($scope.CurrentMedicationList, function(item) {
                            if (item.checked) {
                                if (item.text === "Other - (List below)") {
                                    item.checked = false;
                                }
                            }
                        });
                        var newCurrentMedicationItem = {
                            text: $scope.data.CurrentMedicationOther,
                            checked: true
                        };
                        $rootScope.CurrentMedicationList.splice(1, 0, newCurrentMedicationItem);
                        if ($rootScope.checkedMedication === 4) {
                            $scope.closeCurrentMedication();
                        }
                        return $scope.data.CurrentMedicationOther;
                    }
                }
            }]
        });
    };

    $scope.removeCurrentMedication = function(index, item) {
        $scope.patinentCurrentMedication.splice(index, 1);
        var indexPos = $rootScope.CurrentMedicationList.indexOf(item);
        $rootScope.CurrentMedicationList[indexPos].checked = false;
        $rootScope.MedicationCount = $scope.patinentCurrentMedication.length;
        $rootScope.checkedMedication--;
        $rootScope.CurrentMedicationItem = $filter('filter')($scope.CurrentMedicationList, {
            checked: true
        });
    }

    $scope.GoTopriorSurgery = function(PriorSurgeryValid) {
        $state.go('tab.priorSurgeries');
    }
    $scope.getSurgeryPopup = function() {
        $rootScope.LastName1 = '';
        $rootScope.datestr = '';
 $rootScope.selectYearsList = CustomCalendar.getSurgeryYearsList( $rootScope.SelectPatientAge);
        $ionicModal.fromTemplateUrl('templates/surgeryPopup.html', {
            scope: $scope,
            animation: 'slide-in-up',
            focusFirstInput: false,
            backdropClickToClose: false
        }).then(function(modal) {

            $scope.modal = modal;
            $scope.surgery.name = '';
            $scope.surgery.dateString = '';
            $scope.surgery.dateStringMonth = '';
            $scope.surgery.dateStringYear = '';
            $scope.modal.show();
            $timeout(function() {
                $('option').filter(function() {
                    return this.value.indexOf('?') >= 0;
                }).remove();
            }, 100);
        });
    };
    $rootScope.ValidationFunction1 = function($a) {
        function refresh_close() {
            $('.close').click(function() {
                $(this).parent().fadeOut(200);
            });
        }
        refresh_close();
        var top = '<div class="notifications-top-center notificationError"><div class="ErrorContent"> <i class="ion-alert-circled" style="font-size: 22px;"></i> ' + $a + '! </div><div id="notifications-top-center-close" class="close NoticationClose"><span class="ion-ios-close-outline" ></span></div></div>';
        $("#notifications-top-center").remove();
        $(".ErrorMessage").append(top);
        refresh_close();
    }
    $scope.surgery = {};
    $scope.closeSurgeryPopup = function() {
        $scope.surgery.name;
       $scope.surgery.dateString;
        var selectedSurgeryDate = new Date($scope.surgery.dateStringYear, $scope.surgery.dateStringMonth - 1, 01);
        $scope.surgery.dateString = selectedSurgeryDate;
        var patientBirthDateStr = new Date($rootScope.PatientAge);
        var isSurgeryDateValid = true;
        if (selectedSurgeryDate < patientBirthDateStr) {
            isSurgeryDateValid = false;
        }
        var today = new Date();
        var mm = today.getMonth() + 1;
        var yyyy = today.getFullYear();
        var isSurgeryDateIsFuture = true;
        if (+$scope.surgery.dateStringYear === yyyy) {
            if (+$scope.surgery.dateStringMonth > mm) {
                isSurgeryDateIsFuture = false;
            }
        }
        if ($scope.surgery.name === '' || $scope.surgery.name === undefined) {
            $scope.ErrorMessage = "Please provide a name/description for this surgery";
            $rootScope.ValidationFunction1($scope.ErrorMessage);
        } else if (($scope.surgery.dateStringMonth === '' || $scope.surgery.dateStringMonth === undefined || $scope.surgery.dateStringYear === '' || $scope.surgery.dateStringYear === undefined)) {
            $scope.ErrorMessage = "Please enter the date as MM/YYYY";
            $rootScope.ValidationFunction1($scope.ErrorMessage);
        }else if(!isSurgeryDateValid){
            $scope.ErrorMessage = "Surgery date should not be before your birthdate";
			$rootScope.ValidationFunction1($scope.ErrorMessage);
        } else if (!isSurgeryDateIsFuture) {
            $scope.ErrorMessage = "Surgery date should not be the future Date";
            $rootScope.ValidationFunction1($scope.ErrorMessage);
        } else {
            SurgeryStocksListService.addSurgery($scope.surgery.name, $scope.surgery.dateString);
            $rootScope.patientSurgeriess = SurgeryStocksListService.SurgeriesList;
            $rootScope.IsToPriorCount = $rootScope.patientSurgeriess.length;
            $scope.modal.hide();
        }
    }
    $scope.RemoveSurgeryPopup = function() {
        $scope.data.searchProvider='';
        $scope.modal.hide();
    };
    $scope.removePriorSurgeries = function(index, item) {
        $rootScope.patientSurgeriess.splice(index, 1);
        var indexPos = $rootScope.patientSurgeriess.indexOf(item);
        $rootScope.IsToPriorCount--;
    }

    $scope.ConsultationSaveData = {
        "medicationAllergies": [],
        "surgeries": [],
        "medicalConditions": [],
        "medications": [],
        "infantData": [],
        "concerns": []
    };
    $rootScope.doPutConsultationSave = function() {
        for (var i = 0; i < $rootScope.AllegiesCount; i++) {
            $scope.medFilter = $filter('filter')($scope.ConsultationSaveData.medicationAllergies, {
                code: $rootScope.patinentMedicationAllergies[i].codeId
            });
            if ($scope.medFilter.length === 0) {
                $scope.ConsultationSaveData.medicationAllergies.push({
                    code: $rootScope.patinentMedicationAllergies[i].codeId,
                    description: $rootScope.patinentMedicationAllergies[i].text
                });
            }
        }
        for (var i = 0; i < $rootScope.IsToPriorCount; i++) {
            date1 = new Date($rootScope.patientSurgeriess[i].Date);
            year = date1.getFullYear();
            month = (date1.getMonth()) + 1;
            $scope.surgeryFilter = $filter('filter')($scope.ConsultationSaveData.surgeries, {
                description: $rootScope.patientSurgeriess[i].Name
            });
            if ($scope.surgeryFilter.length == 0) {
                $scope.ConsultationSaveData.surgeries.push({
                    description: $rootScope.patientSurgeriess[i].Name,
                    month: month,
                    year: year
                });
            }
        }
        for (var i = 0; i < $rootScope.ChronicCount; i++) {
            $scope.chronicFilter = $filter('filter')($scope.ConsultationSaveData.medicalConditions, {
                code: $rootScope.PatientChronicCondition[i].codeId
            });
            if ($scope.chronicFilter.length === 0) {
                $scope.ConsultationSaveData.medicalConditions.push({
                    code: $rootScope.PatientChronicCondition[i].codeId,
                    description: $rootScope.PatientChronicCondition[i].text
                });
            }
        }
        for (var i = 0; i < $rootScope.MedicationCount; i++) {
            $scope.medicationFilter = $filter('filter')($scope.ConsultationSaveData.medications, {
                code: $rootScope.patinentCurrentMedication[i].codeId
            });
            if ($scope.medicationFilter.length === 0) {
                $scope.ConsultationSaveData.medications.push({
                    code: $rootScope.patinentCurrentMedication[i].codeId,
                    description: $rootScope.patinentCurrentMedication[i].text
                });
            }
        }
        if (typeof $rootScope.PrimaryConcernText !== 'undefined') {
            $scope.primaryFilter = $filter('filter')($scope.ConsultationSaveData.concerns, {
                description: $rootScope.PrimaryConcernText
            });
            if ($scope.primaryFilter.length === 0) {
                $scope.ConsultationSaveData.concerns.push({
                    isPrimary: true,
                    description: $rootScope.PrimaryConcernText,
                    customCode: {
                        code: $rootScope.codeId,
                        description: $rootScope.PrimaryConcernText
                    }
                });
            }
        }
        if (typeof $rootScope.SecondaryConcernText !== 'undefined') {
            $scope.sceondFilter = $filter('filter')($scope.ConsultationSaveData.concerns, {
                description: $rootScope.SecondaryConcernText
            });
            if ($scope.sceondFilter.length == 0) {
                $scope.ConsultationSaveData.concerns.push({
                    isPrimary: false,
                    description: $rootScope.SecondaryConcernText,
                    customCode: {
                        code: $rootScope.SecondarycodeId,
                        description: $rootScope.SecondaryConcernText
                    }
                });
            }
        }

        var params = {
            consultationId: $rootScope.consultationId,
            accessToken: $rootScope.accessToken,
            ConsultationSaveData: $scope.ConsultationSaveData,
            success: function(data) {
              if(!angular.isUndefined($rootScope.getIndividualPatientCreditCount) && $rootScope.getIndividualPatientCreditCount !== 0 && $rootScope.paymentMode === 'on') {
                $rootScope.doPostDepitDetails();
              } else {
                  $scope.ConsultationSave = "success";
                  if ($rootScope.paymentMode === 'on' && $rootScope.consultationAmount !== 0) {
                      $rootScope.doGetPatientPaymentProfiles();
                  }
                  $rootScope.enableInsuranceVerificationSuccess = "none";
                  $rootScope.enableCreditVerification = "none";
                    $rootScope.enableWaivefeeVerification = "none";
                  if ($rootScope.insuranceMode === 'on' && $rootScope.paymentMode === 'on') {
                      $rootScope.openAddHealthPlanSection();
                  }
                  if ($rootScope.insuranceMode != 'on' && $rootScope.paymentMode != 'on') {
                      $rootScope.enablePaymentSuccess = "none";
                      $rootScope.enableCreditVerification = "none";
                        $rootScope.enableWaivefeeVerification = "none";
                      $state.go('tab.receipt');
                      $scope.ReceiptTimeout();
                  } else if ($rootScope.insuranceMode === 'on' && $rootScope.paymentMode !== 'on') {
                      $rootScope.openAddHealthPlanSection();
                      $state.go('tab.consultCharge');
                  } else {
                      if ($rootScope.consultationAmount > 0) {
                          if ($rootScope.insuranceMode !== 'on' && $rootScope.paymentMode === 'on') {
                              $rootScope.healthPlanPage = "none";
                              $rootScope.consultChargeNoPlanPage = "block";
                          }
                          $state.go('tab.consultCharge');
                          if (typeof $rootScope.userDefaultPaymentProfile == "undefined") {
                              $('#addNewCard').val('Choose Your Card');
                              $('#addNewCard_addCard').val('Choose Your Card');
                              $('#addNewCard_submitPay').val('Choose Your Card');
                              $rootScope.userDefaultPaymentProfileText = 'undefined';
                          } else {
                              $('#addNewCard').val($rootScope.userDefaultPaymentProfile);
                              $('#addNewCard_addCard').val($rootScope.userDefaultPaymentProfile);
                              $('#addNewCard_submitPay').val($rootScope.userDefaultPaymentProfile);
                              $rootScope.paymentProfileId = $rootScope.userDefaultPaymentProfile;
                              $scope.cardPaymentId.addNewCard = $rootScope.userDefaultPaymentProfile;
                          }
                      } else {
                          $rootScope.enablePaymentSuccess = "none";
                          $rootScope.enableCreditVerification = "none";
                            $rootScope.enableWaivefeeVerification = "none";
                          $state.go('tab.receipt');
                          $scope.ReceiptTimeout();
                      }
                  }
              }
            },
            error: function(data,status) {
              if(status===0 ){
                   $scope.ErrorMessage = "Internet connection not available, Try again later!";
                   $rootScope.Validation($scope.ErrorMessage);

              }else{
                $rootScope.serverErrorMessageValidation();
              }
            }
        };
        LoginService.putConsultationSave(params);
    }
    $rootScope.doPostDepitDetails = function() {
        var params = {
            patientId: $rootScope.patientId,
            consultationId: $rootScope.consultationId,
            accessToken: $rootScope.accessToken,
            success: function(data) {
              $state.go('tab.receipt');
              $rootScope.enablePaymentSuccess = "none";
              $rootScope.enableInsuranceVerificationSuccess = "none";
              $rootScope.enableCreditVerification = "block";
                $rootScope.enableWaivefeeVerification = "none";
              $scope.ReceiptTimeout();
            },
            error: function(data,status) {
              if(status===0 ){
                   $scope.ErrorMessage = "Internet connection not available, Try again later!";
                   $rootScope.Validation($scope.ErrorMessage);

              }else{
                $rootScope.serverErrorMessageValidation();
              }
            }
        };
        LoginService.postDepitDetails(params);
    }


    $scope.ReceiptTimeout = function() {
        var currentTimeReceipt = new Date();
        currentTimeReceipt.setSeconds(currentTimeReceipt.getSeconds() + 10);
        $rootScope.ReceiptTime = currentTimeReceipt.getTime();
        $.getScript( "lib/jquery.signalR-2.1.2.js", function( data, textStatus, jqxhr ) {

        });

        setTimeout(function() {
            $state.go('tab.waitingRoom');
        }, 10000);
    }
    $scope.clearRootScopeConce = function() {
        navigator.notification.confirm(
            'Are you sure that you want to cancel this consultation?',
            function(index) {
                if (index == 1) {

                } else if (index == 2) {
                  $rootScope.PatientPrimaryConcernItem;
                  $rootScope.PatientPrimaryConcern = "";
                    $rootScope.primaryConcernList="";
                    $rootScope.secondaryConcernList="";
                    $scope.PatientPrimaryConcernItem="";
                    $rootScope.primaryconcern=false;
                    $rootScope.secondaryconcern=false;
                    $rootScope.PatientSecondaryConcern = "";
                    $rootScope.PatientChronicCondition = "";
                    $rootScope.patinentCurrentMedication = "";
                    $rootScope.patinentMedicationAllergies = "";
                    $rootScope.patientSurgeriess = "";
                    $rootScope.MedicationCount == 'undefined';
                    $rootScope.checkedChronic = 0;
                    $rootScope.ChronicCount = "";
                    $rootScope.AllegiesCount = "";
                    $rootScope.checkedAllergies = 0;
                    $rootScope.MedicationCount = "";
                    $rootScope.checkedMedication = 0;
                    $rootScope.IsValue = "";
                    $rootScope.IsToPriorCount = "";
                    $rootScope.ChronicCountValidCount = "";
                    $rootScope.PriorSurgeryValidCount = "";
                    $rootScope.AllegiesCountValid = "";
                    $rootScope.MedicationCountValid = "";
                    SurgeryStocksListService.ClearSurgery();
                    $state.go('tab.userhome');
                }
            },
            'Confirmation:', ['No', 'Yes']
        );

    };
    //Side Menu
    var checkAndChangeMenuIcon;
    $interval.cancel(checkAndChangeMenuIcon);
    $rootScope.checkAndChangeMenuIcon = function() {
        if (!$ionicSideMenuDelegate.isOpen(true)) {
            if ($('#BackButtonIcon').hasClass("ion-close")) {
                $('#BackButtonIcon').removeClass("ion-close");
                $('#BackButtonIcon').addClass("ion-navicon-round");
            }
        } else {
            if ($('#BackButtonIcon').hasClass("ion-navicon-round")) {
                $('#BackButtonIcon').removeClass("ion-navicon-round");
                $('#BackButtonIcon').addClass("ion-close");
            }
        }
    }
    $scope.toggleLeft = function() {
        $ionicSideMenuDelegate.toggleLeft();
        $rootScope.checkAndChangeMenuIcon();
        if (checkAndChangeMenuIcon) {
            $interval.cancel(checkAndChangeMenuIcon);
        }
        if ($state.current.name !== "tab.login" || $state.current.name !== "tab.loginSingle") {
            checkAndChangeMenuIcon = $interval(function() {
                $rootScope.checkAndChangeMenuIcon();
            }, 300);
        }
    };

    $scope.goTOSchedule = function() {
        /* $("#style1").attr("disabled", "disabled");
          $("#style2").attr("disabled", "disabled");*/
        $('<link/>', {
            rel: 'stylesheet',
            type: 'text/css',
            href: 'css/styles.v3.less.dynamic.css'
        }).appendTo('head');
        //  $state.go('tab.providerSearch', { viewMode : 'all' });
        $state.go('tab.providerSearch');
    }
})
